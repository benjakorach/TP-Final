import React from 'react'

export const UrlGit = () => {
  return (
      <h1>https://github.com/clod2008/FundamentosJS</h1>
  )
}
