import React from 'react'
import './footer.css'

export const Footer = () => {
  return (
    <footer>
        <h1>Footer</h1>
    </footer>
  )
}
