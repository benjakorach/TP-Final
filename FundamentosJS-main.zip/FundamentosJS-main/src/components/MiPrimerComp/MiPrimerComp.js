import React from 'react'
import './miPrimerComp.css'

export const MiPrimerComp = () => {
    return (
        <>
            <h1>Fundamentos JS</h1>
            <hr className='mb-4' />
        </>
    )
}
