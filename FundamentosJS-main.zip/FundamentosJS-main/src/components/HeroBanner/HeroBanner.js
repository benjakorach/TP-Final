import React from 'react'
import './hetoBanner.css'

export const HeroBanner = () => {
  return (

    <div id='HeroBanner'>
          <h1 className='pt-5'>HeroBanner</h1>
          <button>Boton uno</button>
    </div>
  )
}
