const productos = [
    {
        id: 'sku001',
        title: 'Producto 01',
        text:  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum bibendum sem quis congue gravida. Fusce feugiat porta quam, at congue velit blandit at. Etiam porta gravida lacus in elementum. Ut sagittis facilisis massa at malesuada. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean non euismod erat. Fusce vitae vehicula quam. Sed nisl lorem, porta vel augue vehicula, elementum molestie massa.',
        img: 'https://picsum.photos/200/200?random=1',
        categorie: 'cat01'
    },
    {
        id: 'sku002',
        title: 'Producto 02',
        text:  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum bibendum sem quis congue gravida. Fusce feugiat porta quam, at congue velit blandit at. Etiam porta gravida lacus in elementum. Ut sagittis facilisis massa at malesuada. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean non euismod erat. Fusce vitae vehicula quam. Sed nisl lorem, porta vel augue vehicula, elementum molestie massa.',
        img: 'https://picsum.photos/200/200?random=2',
        categorie: 'cat02'
    },
    {
        id: 'sku003',
        title: 'Producto 03',
        text:  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum bibendum sem quis congue gravida. Fusce feugiat porta quam, at congue velit blandit at. Etiam porta gravida lacus in elementum. Ut sagittis facilisis massa at malesuada. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean non euismod erat. Fusce vitae vehicula quam. Sed nisl lorem, porta vel augue vehicula, elementum molestie massa.',
        img: 'https://picsum.photos/200/200?random=3',
        categorie: 'cat01'
    },
    {
        id: 'sku004',
        title: 'Producto 04',
        text:  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum bibendum sem quis congue gravida. Fusce feugiat porta quam, at congue velit blandit at. Etiam porta gravida lacus in elementum. Ut sagittis facilisis massa at malesuada. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean non euismod erat. Fusce vitae vehicula quam. Sed nisl lorem, porta vel augue vehicula, elementum molestie massa.',
        img: 'https://picsum.photos/200/200?random=4',
        categorie: 'cat02'
    },
    {
        id: 'sku005',
        title: 'Producto 05',
        text:  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum bibendum sem quis congue gravida. Fusce feugiat porta quam, at congue velit blandit at. Etiam porta gravida lacus in elementum. Ut sagittis facilisis massa at malesuada. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean non euismod erat. Fusce vitae vehicula quam. Sed nisl lorem, porta vel augue vehicula, elementum molestie massa.',
        img: 'https://picsum.photos/200/200?random=5',
        categorie: 'cat01'
    },
]

const navButtos =[
    {
        link: '#',
        text: 'Home',
    },
    {
        link: '#',
        text: 'Tema 01',
    },
    {
        link: '#',
        text: 'Contactos',
    },
]

export {
    productos,
    navButtos

}